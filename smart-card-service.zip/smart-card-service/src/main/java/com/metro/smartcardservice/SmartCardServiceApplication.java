package com.metro.smartcardservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartCardServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartCardServiceApplication.class, args);
	}

}
