package com.metro.smartcardservice.exception;

public class InsufficientBalanceException extends Exception 
{
	private static final long serialVersionUID = -7389346752543787623L;

	public InsufficientBalanceException( String message )
	{
		super( message );
	}
}
