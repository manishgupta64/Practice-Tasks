package com.metro.smartcardservice.metro.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table( name="TRAVEL_DETAILS" )
public class TravelDetails implements Serializable 
{

	private static final long serialVersionUID = -3431753164075787473L;
	
	@Id
	@GeneratedValue ( strategy = GenerationType.AUTO )
	private int travelId;
	
	private int sourceStationId;
	
	private int destinationStationId;
	
	private double fare;
	
	private Date journeyDate;
	
	private boolean fairPaid;
	
	public TravelDetails( int sourceId, int destId, double fare )
	{
		this.sourceStationId = sourceId;
		this.destinationStationId = destId;
		this.journeyDate = new Date();
	}
	
	public TravelDetails()
	{
		
	}

	public int getTravelId() {
		return travelId;
	}

	public void setTravelId(int travelId) {
		this.travelId = travelId;
	}

	public int getSourceStationId() {
		return sourceStationId;
	}

	public void setSourceStationId(int sourceStationId) {
		this.sourceStationId = sourceStationId;
	}

	public int getDestinationStationId() {
		return destinationStationId;
	}

	public void setDestinationStationId(int destinationStationId) {
		this.destinationStationId = destinationStationId;
	}

	public double getFare() {
		return fare;
	}

	public void setFare(double fare) {
		this.fare = fare;
	}

	public Date getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(Date journeyDate) {
		this.journeyDate = journeyDate;
	}

	public boolean isFairPaid() {
		return fairPaid;
	}

	public void setFairPaid(boolean fairPaid) {
		this.fairPaid = fairPaid;
	}
	
}
