package com.metro.smartcardservice.metro.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="USER_SMART_CARD")
public class SmartCard implements Serializable 
{

	private static final long serialVersionUID = 8002824906194133464L;
	
	@Id
	@GeneratedValue ( strategy = GenerationType.AUTO )
	private long cardId;
	
	private double balance;
	
	@OneToMany( cascade = CascadeType.ALL, fetch = FetchType.LAZY )
	@JoinColumn( name="cardId" )
	List< TravelDetails > travelHistory = new ArrayList<>();
	
	public SmartCard( double balance )
	{
		this.balance = balance;
	}
	
	public SmartCard()
	{
		
	}
	
	public long getCardId() {
		return cardId;
	}

	public void setCardId(long cardId) {
		this.cardId = cardId;
	}
	
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public List<TravelDetails> getTravelHistory() {
		return travelHistory;
	}

	public void setTravelHistory(List<TravelDetails> travelHistory) {
		this.travelHistory = travelHistory;
	}
	
}
