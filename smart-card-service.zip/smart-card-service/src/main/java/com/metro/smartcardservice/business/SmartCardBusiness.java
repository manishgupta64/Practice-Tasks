package com.metro.smartcardservice.business;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.metro.smartcardservice.dao.SmartCardRepository;
import com.metro.smartcardservice.farestrategy.FareStrategy;
import com.metro.smartcardservice.farestrategy.WeekdayFareStrategy;
import com.metro.smartcardservice.farestrategy.WeekendFareStrategy;
import com.metro.smartcardservice.metro.model.CardSwipeIn;
import com.metro.smartcardservice.metro.model.CardSwipeOut;
import com.metro.smartcardservice.metro.model.SmartCard;
import com.metro.smartcardservice.metro.model.TravelDetails;

@Service
public class SmartCardBusiness implements ISmartCardBusiness 
{

	@Autowired
	SmartCardRepository smartCardDao;
	
	@Override
	public SmartCard allocateNewCard( SmartCard card ) 
	{
		card = smartCardDao.save( card );
		return card;
	}

	@Override
	public SmartCard getCardDetails( long  cardId ) {
		
		Optional< SmartCard > smartCard = smartCardDao.findById(cardId);
		if( smartCard.isPresent() )
		{
			return smartCard.get();
		}
		return null;
	}

	@Override
	public Map<String, Object> swipeIn(CardSwipeIn swipeInData ) 
	{
		Map< String, Object > data = new HashMap<>(); 
		if( swipeInData ==  null )
		{
			throw new IllegalArgumentException("Invalid smartCard data");
		}
		Optional<SmartCard> smartCard = smartCardDao.findById( swipeInData.getCardId() );
		if( smartCard.isPresent() ) 
		{
			LocalDateTime dateTime = LocalDateTime.now();
			FareStrategy fareStrategy = getFareStrategy(dateTime);;
			boolean canSwipeIn = false;
			if( fareStrategy.farePerStation() <= smartCard.get().getBalance() )
			{
				canSwipeIn = true;
				TravelDetails journey = new TravelDetails( swipeInData.getStationId(), -1, 0 );
				smartCard.get().getTravelHistory().add(journey);
				smartCardDao.save( smartCard.get() );
			}
			data.put("canSwipeIn", String.valueOf( canSwipeIn ) );
			return data;
		}
		return null;
	}

	@Override
	public Map<String, Object> swipeOut(CardSwipeOut swipeOutData) 
	{
		Map< String, Object > data = new HashMap<>();
		Optional< SmartCard > smartCardOptionalObj = smartCardDao.findById(swipeOutData.getCardId());
		if( smartCardOptionalObj.isPresent() )
		{
			SmartCard smartCard = smartCardOptionalObj.get();
			Optional< TravelDetails > lastJourney = Optional.ofNullable(smartCard.getTravelHistory().get( smartCard.getTravelHistory().size() - 1 ) );
			if( lastJourney.isPresent() )
			{
				TravelDetails journey = lastJourney.get();
				journey.setDestinationStationId( swipeOutData.getStationId());
				// calculate fare
				LocalDateTime dateTime = LocalDateTime.now();
				FareStrategy fareStrategy = getFareStrategy(dateTime);
				double totalFare = fareStrategy.farePerStation() * ( journey.getDestinationStationId() - journey.getSourceStationId() );  
				journey.setFare( totalFare );
				if( journey.getFare() <= smartCard.getBalance() )
				{
					smartCard.setBalance( smartCard.getBalance() - totalFare );
					// save the smart card
					smartCard.getTravelHistory().stream().forEach( j -> {
						if( journey.getTravelId() == j.getTravelId() )
						{
							j.setDestinationStationId( journey.getDestinationStationId() );
							j.setFare( journey.getFare());
							j.setFairPaid(true);
						}
					});
					smartCardDao.save( smartCard );
					data.put("swipedOut", String.valueOf("true"));
				}
				else
				{
					data.put("error", "Insufficient Balance to swipe out, Please contact customerCare or recharge your card");
				}
			}
		}
		return data;
	}
	
	private FareStrategy getFareStrategy( LocalDateTime dateTime )
	{
		FareStrategy fareStrategy = null;
		if( dateTime.getDayOfWeek() == DayOfWeek.SATURDAY || dateTime.getDayOfWeek() == DayOfWeek.SUNDAY )
		{
			fareStrategy = new WeekendFareStrategy();
		}
		else
		{
			fareStrategy = new WeekdayFareStrategy();
		}
		return fareStrategy;
	}

}
