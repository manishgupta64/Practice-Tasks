package com.metro.smartcardservice.business;

import java.util.Map;

import com.metro.smartcardservice.metro.model.CardSwipeIn;
import com.metro.smartcardservice.metro.model.CardSwipeOut;
import com.metro.smartcardservice.metro.model.SmartCard;

public interface ISmartCardBusiness 
{
	SmartCard allocateNewCard( SmartCard card );
	
	SmartCard getCardDetails( long cardId );
	
	Map<String, Object > swipeIn( CardSwipeIn swipeInData );
	
	Map< String, Object > swipeOut( CardSwipeOut swipeOutData );
}
