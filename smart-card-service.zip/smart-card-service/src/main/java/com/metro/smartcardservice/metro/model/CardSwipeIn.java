package com.metro.smartcardservice.metro.model;

import java.io.Serializable;

public class CardSwipeIn implements Serializable 
{
	private static final long serialVersionUID = -3043836069911290304L;
	
	private long cardId;
	
	private int stationId;

	public long getCardId() {
		return cardId;
	}

	public void setCardId(long cardId) {
		this.cardId = cardId;
	}

	public int getStationId() {
		return stationId;
	}

	public void setStationId(int stationId) {
		this.stationId = stationId;
	}
	
}
