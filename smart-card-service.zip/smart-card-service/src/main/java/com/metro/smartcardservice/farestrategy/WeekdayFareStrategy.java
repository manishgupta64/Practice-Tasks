package com.metro.smartcardservice.farestrategy;

public class WeekdayFareStrategy implements FareStrategy 
{

	@Override
	public String getName() {
		
		return "Week Day";
	}

	@Override
	public double farePerStation() {
		
		return 7;
	}

}
