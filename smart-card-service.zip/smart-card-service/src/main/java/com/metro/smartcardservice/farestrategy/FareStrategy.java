package com.metro.smartcardservice.farestrategy;

public interface FareStrategy 
{
	String getName();
	
	double farePerStation(); 
}
