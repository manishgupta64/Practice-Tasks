package com.metro.smartcardservice.farestrategy;

public class WeekendFareStrategy implements FareStrategy
{

	@Override
	public String getName() {
		return "Saturday-Sunday";
	}

	@Override
	public double farePerStation() {
		return 5.5;
	}
	
}
