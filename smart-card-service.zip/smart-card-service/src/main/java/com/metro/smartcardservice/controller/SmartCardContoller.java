package com.metro.smartcardservice.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.metro.smartcardservice.business.ISmartCardBusiness;
import com.metro.smartcardservice.exception.InsufficientNewCardAmountException;
import com.metro.smartcardservice.metro.model.CardSwipeIn;
import com.metro.smartcardservice.metro.model.CardSwipeOut;
import com.metro.smartcardservice.metro.model.SmartCard;

@RestController
public class SmartCardContoller 
{
	@Autowired
	ISmartCardBusiness smartCardService;

	@PostMapping("/smartCard/allocate/{initialBalance}")
	public ResponseEntity<?> allocateNewSmartCard( @PathVariable Double initialBalance, HttpServletRequest request, HttpServletResponse response )
	{
		Map< String, String > errors  = new HashMap<>();
		try
		{
			if( initialBalance == null || initialBalance < 150 )
			{
				errors.put("error", String.valueOf("true"));
				errors.put("message", "Minimum 150 required for new card!");
				throw new InsufficientNewCardAmountException("Minimum 150 required for new card!");
			}
			SmartCard newCard = new SmartCard( initialBalance );
			newCard = smartCardService.allocateNewCard( newCard );
			return ResponseEntity.ok( newCard );
		}
		catch( Exception e )
		{
			return ResponseEntity.ok( errors );
		}
	}
	
	@GetMapping("/smartCard/travelHistory/{cardId}")
	public ResponseEntity< ? > travelHistory( @PathVariable Long cardId, HttpServletRequest request, HttpServletResponse response )
	{
		Map< String, String > errors  = new HashMap<>();
		try 
		{
			if( cardId <= 0 )
			{
				errors.put("error", String.valueOf("true"));
				errors.put("message", "Invalid Card Id!");
				throw new IllegalArgumentException("Card id is not valid!!! : " + cardId );
			}
			SmartCard smartCard = smartCardService.getCardDetails(cardId);
			return ResponseEntity.ok( smartCard );
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			return ResponseEntity.ok( errors );
		}		
	}
	
	@PostMapping("/smartCard/swipeIn")
	public ResponseEntity< ? > swipeIn( @RequestBody CardSwipeIn swipeInData, HttpServletRequest request, HttpServletResponse response )
	{
		Map< String, String > errors  = new HashMap<>();
		try
		{
			if( swipeInData == null || swipeInData.getCardId() <= 0 )
			{
				errors.put("error", String.valueOf("true"));
				errors.put("message", "Invalid Card Id!");
				throw new IllegalArgumentException("Card id is not valid!!! : " + swipeInData.getCardId() );
			}
			Map< String, Object > data = smartCardService.swipeIn(swipeInData);
			if( data != null )
			{
				return ResponseEntity.ok(data);
			}
			else
			{
				errors.put("error", String.valueOf("true"));
				errors.put("message", "Something Went Wrong!!!");
				return ResponseEntity.ok(errors);
			}
			
		}
		catch( Exception e )
		{
			return ResponseEntity.ok( errors );
		}
	}
	
	@PostMapping("/smartCard/swipeOut")
	public ResponseEntity<?> swipeOut( @RequestBody CardSwipeOut swipeOutData, HttpServletRequest request, HttpServletResponse response  )
	{
		Map< String, String > errors  = new HashMap<>();
		try 
		{
			if( swipeOutData == null || swipeOutData.getCardId() <= 0 )
			{
				errors.put("error", String.valueOf("true"));
				errors.put("message", "Invalid Card Id!");
				throw new IllegalArgumentException("Card id is not valid!!! : " + swipeOutData.getCardId() );
			}
			if( swipeOutData.getStationId() <= 0 )
			{
				errors.put("error", String.valueOf("true"));
				errors.put("message", "Invalid stationId!");
				throw new IllegalArgumentException("Invalid destination station Id!!! : " + swipeOutData.getStationId() );
			}
			Map< String, Object > data = smartCardService.swipeOut(swipeOutData);
			return ResponseEntity.ok(data);
			
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();		// here we can use the logger to log the issues
			return ResponseEntity.ok( errors );
		}
	}
	
	@GetMapping("/smartCard/travelReport/{cardId}")
	public ResponseEntity< ? > travelReport( @PathVariable Long cardId, HttpServletRequest request, HttpServletResponse response )
	{
		Map< String, String > errors  = new HashMap<>();
		try 
		{
			if( cardId == 0 )
			{
				errors.put("error", String.valueOf("true"));
				errors.put("message", "Invalid Card Id!");
				throw new IllegalArgumentException("Card id is not valid!!! : " + cardId );
			}
			SmartCard smartCard = smartCardService.getCardDetails(cardId);
			return ResponseEntity.ok( smartCard.getTravelHistory() );
			
		} catch (Exception e) 
		{
			e.printStackTrace();
			return ResponseEntity.ok( errors );
		}
		
	}
	
	
}
