package com.metro.smartcardservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.metro.smartcardservice.metro.model.SmartCard;

@Repository
public interface SmartCardRepository extends JpaRepository<SmartCard, Long>   
{
	
}
