package com.metro.smartcardservice.exception;

public class InsufficientNewCardAmountException extends Exception
{
	private static final long serialVersionUID = -6562351566190817067L;

	public InsufficientNewCardAmountException( String message )
	{
		super( message );
	}
	
}
