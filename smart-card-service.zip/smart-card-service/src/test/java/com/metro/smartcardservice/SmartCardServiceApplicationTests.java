package com.metro.smartcardservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartCardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
